
#include <complex.h>

extern complex double xpolygon(int N, const double pg[N][2], const double p[3]);
extern complex double kpolygon(int N, const double pg[N][2], const double q[3]);

