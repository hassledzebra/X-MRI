


extern int dicom_write(const char* name, unsigned int cols, unsigned int rows, long inum, const unsigned char* img);

